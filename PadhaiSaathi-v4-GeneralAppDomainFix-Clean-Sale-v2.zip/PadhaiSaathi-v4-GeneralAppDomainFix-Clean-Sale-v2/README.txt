Padhai Saathi v4

Run PadhaiSaathi.exe to start the app.

Requirements:
- Windows 10/11, 64-bit
- .NET 10 Desktop Runtime

This clean distribution package does not include music, user profiles, session history, streaks, or backups. Each user's app data is stored locally on their own PC. Users can add their own audio files in the app.
